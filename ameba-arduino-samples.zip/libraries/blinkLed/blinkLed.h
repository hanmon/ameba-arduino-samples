#include "Arduino.h"
#define FAST	100
#define MEDIUM	500
#define SLOW	1000
void blinkLed(int pin, int duration, int count);

